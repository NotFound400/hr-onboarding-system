package org.example.applicationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
