package org.example.applicationservice.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class HRRequestDTO {
    private String comment;
}
