package org.example.applicationservice.exception;

public class ApplicationServiceException extends RuntimeException{
    public ApplicationServiceException(String message) {
        super(message);
    }
}
